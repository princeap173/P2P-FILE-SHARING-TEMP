# P2P-Folder-Sharing
### Computer Networks Project
To run the script:
                 python3 NewServer.py <br>
Log for the server can be found in the file "server.log" which will be created in the same folder where the script for the server exists
